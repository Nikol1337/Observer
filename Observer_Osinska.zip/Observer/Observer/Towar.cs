﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{

    public class Towar
    {
        private Kraje kraj;
        private double cenaPLN;
        private double cenaOrginalna;
        private string nazwa;

        public Kraje getKraj()
        {
            return kraj;
        }
        public double getCenaOrignalna()
        {
            return cenaOrginalna;
        }
        public string getNazwa() { return  nazwa; }
        public double getCenaPLN() { return cenaPLN; }
        public void setCenaPLN(double kurs) { cenaPLN = kurs*cenaOrginalna; } 
        public Towar(Kraje kraj, double kurs, double cenaOrginalna,string nazwa)
        {

            this.cenaPLN = kurs*cenaOrginalna;
            this.kraj = kraj;
            this.cenaOrginalna = cenaOrginalna;
            this.nazwa = nazwa;
        }
    }
}
