﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{
    public enum Kraje
    {
        Anglia,
        Niemcy,
        Rosja,
        Ukraina  
    }
    public static class NBP
    {
         static Dictionary<Kraje, double> Kursy = new Dictionary<Kraje, double>();
         static List<Sklep> obserwatorzy = new List<Sklep>();

        static NBP() {
            Kursy.Add(Kraje.Anglia, 5.0);
            Kursy.Add(Kraje.Niemcy, 4.0);
            Kursy.Add(Kraje.Rosja, 0.02);
            Kursy.Add(Kraje.Ukraina, 0.1);
        }
        public static double getKurs(Kraje kraj)
        {
            return Kursy[kraj];
        }

        public static void ZarejestrujObserwatora(Sklep sklep)
        {
            if(!obserwatorzy.Contains(sklep))
            obserwatorzy.Add(sklep);
            

        }
        public static void ZmienKurs(Kraje kraj,double nowyKurs)
        {
            Kursy[kraj] = nowyKurs;
            foreach(var k in obserwatorzy)
            {
                k.aktualizujCene();
            }
        }
    }

}
