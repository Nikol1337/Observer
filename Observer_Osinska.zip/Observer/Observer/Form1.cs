namespace Observer
{
    public partial class Form1 : Form
    {
        
        private Sklep pierwszy;
        private Sklep drugi;
        //private TextBox 

        public void dodajKolumny()
        {
            listView1.Columns.Add("Nazwa", 100);
            listView1.Columns.Add("CenaPLN", 100);
            listView1.Columns.Add("Cena orginalna", 100);
            listView1.Columns.Add("Kraj", 100);

            listView2.Columns.Add("Nazwa", 100);
            listView2.Columns.Add("CenaPLN", 100);
            listView2.Columns.Add("Cena orginalna", 100);
            listView2.Columns.Add("Kraj", 100);
        }
        public Form1()
        {
            InitializeComponent();
           
            pierwszy = new Sklep();
            drugi = new Sklep();
            Towar monitor = new Towar(Kraje.Niemcy, NBP.getKurs(Kraje.Niemcy), 50.0, "monitor");
            Towar monitorLCD = new Towar(Kraje.Rosja, NBP.getKurs(Kraje.Rosja), 5000.0, "monitorLCD");
            Towar Myszka = new Towar(Kraje.Niemcy, NBP.getKurs(Kraje.Niemcy), 5.0, "Myszka");
            Towar Klawiatura = new Towar(Kraje.Anglia, NBP.getKurs(Kraje.Anglia), 13.0, "Klawiatura");
            Towar podkladka = new Towar(Kraje.Ukraina, NBP.getKurs(Kraje.Ukraina), 1500.0, "podkladka");
            Towar pad = new Towar(Kraje.Anglia, NBP.getKurs(Kraje.Anglia), 20.0, "pad");
            Towar tablet = new Towar(Kraje.Rosja, NBP.getKurs(Kraje.Rosja), 15000.0, "tablet");
            pierwszy.dodajTowar(monitor);
            drugi.dodajTowar(monitorLCD);
            pierwszy.dodajTowar(Myszka);
            drugi.dodajTowar(Klawiatura);
            drugi.dodajTowar(podkladka);
            pierwszy.dodajTowar(pad);
            drugi.dodajTowar(tablet);

            dodajKolumny();
            NBP.ZarejestrujObserwatora(pierwszy);

            NBP.ZarejestrujObserwatora(drugi);
            Kraje[] wartosciKraje = (Kraje[])Enum.GetValues(typeof(Kraje));
            comboBox1.DataSource = wartosciKraje;

            foreach (var item in pierwszy.getListe())
            {
                
                ListViewItem nowy = new ListViewItem(item.getNazwa());
                nowy.SubItems.Add(item.getCenaPLN().ToString());
                nowy.SubItems.Add(item.getCenaOrignalna().ToString());
                nowy.SubItems.Add(item.getKraj().ToString());
                listView1.Items.Add(nowy);
            }

            foreach (var item in drugi.getListe())
            {
                
                ListViewItem nowy = new ListViewItem(item.getNazwa());
                nowy.SubItems.Add(item.getCenaPLN().ToString());
                nowy.SubItems.Add(item.getCenaOrignalna().ToString());
                nowy.SubItems.Add(item.getKraj().ToString());
                listView2.Items.Add(nowy);
            }



        }
        private void OdswiezListView()
        {
            listView1.Clear();
            listView2.Clear();

            dodajKolumny();

            foreach (var item in pierwszy.getListe())
            {
              //  nbp.ZarejestrujObserwatora(item.getKraj(), pierwszy);
                ListViewItem nowy = new ListViewItem(item.getNazwa());
                nowy.SubItems.Add(item.getCenaPLN().ToString());
                nowy.SubItems.Add(item.getCenaOrignalna().ToString());
                nowy.SubItems.Add(item.getKraj().ToString());
                listView1.Items.Add(nowy);
            }

            foreach (var item in drugi.getListe())
            {
               // nbp.ZarejestrujObserwatora(item.getKraj(), drugi);
                ListViewItem nowy = new ListViewItem(item.getNazwa());
                nowy.SubItems.Add(item.getCenaPLN().ToString());
                nowy.SubItems.Add(item.getCenaOrignalna().ToString());
                nowy.SubItems.Add(item.getKraj().ToString());
                listView2.Items.Add(nowy);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            double wartosc = double.Parse(textBox1.Text);
            if(wartosc>0) {

                if (comboBox1.SelectedItem != null)
                {
                    Kraje wybranyKraj = (Kraje)comboBox1.SelectedItem;
                    NBP.ZmienKurs(wybranyKraj, wartosc);

                    OdswiezListView();
                }

            }
        }
    }
}
