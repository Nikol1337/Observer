﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{
    public class Sklep
    {
        public List<Towar> listaTowarow = new List<Towar>();
        public void dodajTowar(Towar towar)
        {
            listaTowarow.Add(towar);
        }
        public List<Towar> getListe()
        {
            return listaTowarow;
        }

        public void aktualizujCene()
        {
            foreach(var item in listaTowarow)
            {
                if(item.getCenaPLN()!=(NBP.getKurs(item.getKraj()))*item.getCenaOrignalna())
                {
                    item.setCenaPLN(NBP.getKurs(item.getKraj()));
                }
            }
        }
    }
}
